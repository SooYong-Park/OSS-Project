package swing;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Name extends JFrame{
	   JButton c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,al,hi,mid,low;
	   TextField b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
	   Info i = new Info();
	     public void name() {
	      JPanel p = new JPanel();
	      p.setLayout(null);
			Label t1= new Label("요리를 선택해주세요");
			add(t1);
			Label t2= new Label("난이도 선택");
			add(t2);


			b1 = new TextField();
			add(b1);
			b2 = new TextField();
			add(b2);
			b3 = new TextField();
			add(b3);
			b4 = new TextField();
			add(b4);
			b5 = new TextField();
			add(b5);
			b6 = new TextField();
			add(b6);
			b7 = new TextField();
			add(b7);
			b8 = new TextField();
			add(b8);
			b9 = new TextField();
			add(b9);
			b10 = new TextField();
			add(b10);
			
			
			
			c1 = new JButton("1번");
			add(c1);
			c2 = new JButton("2번");
			add(c2);
			c3 = new JButton("3번");
			add(c3);
			c4 = new JButton("4번");
			add(c4);
			c5 = new JButton("5번");
			add(c5);
			c6 = new JButton("6번");
			add(c6);
			c7 = new JButton("7번");
			add(c7);
			c8 = new JButton("8번");
			add(c8);
			c9 = new JButton("9번");
			add(c9);
			c10 = new JButton("10번");
			add(c10);
			hi= new JButton("어려움");
			add(hi);
			mid = new JButton("보통");
			add(mid);
			low = new JButton("초보환영");
			add(low);
			al = new JButton("겹침");
			add(al);
			
			
			
			
			t1.setBounds(400, 5, 200, 40);
			t2.setBounds(700, 560, 80, 40);
		
	
			b1.setBounds(80, 80, 700, 30);
			b2.setBounds(80, 120, 700, 30);
			b3.setBounds(80, 160, 700, 30);
			b4.setBounds(80, 200, 700, 30);
			b5.setBounds(80, 240, 700, 30);
			b6.setBounds(80, 280, 700, 30);
			b7.setBounds(80, 320, 700, 30);
			b8.setBounds(80, 360, 700, 30);
			b9.setBounds(80, 400, 700, 30);
			b10.setBounds(80, 440, 700, 30);
			
			
			
			c1.setBounds(800, 80, 60, 30);
			c2.setBounds(800, 120, 60, 30);
			c3.setBounds(800, 160, 60, 30);
			c4.setBounds(800, 200, 60, 30);
			c5.setBounds(800, 240, 60, 30);
			c6.setBounds(800, 280, 60, 30);
			c7.setBounds(800, 320, 60, 30);
			c8.setBounds(800, 360, 60, 30);
			c9.setBounds(800, 400, 60, 30);
			c10.setBounds(800, 440, 60, 30);
			
			hi.setBounds(800, 520, 100, 30);
			mid.setBounds(800, 560, 100, 30);
			low.setBounds(800, 600, 100, 30);
			al.setBounds(80, 520, 100, 120);
			
		
			
			add(p);
			setSize(1000, 700);
			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			setTitle("요리 선택 화면");
			setVisible(true);
			
			 c1.addActionListener(new ActionListener() {
				   public void actionPerformed(ActionEvent e) {
				   	try{
				   	i.info();
				   			}	
				   	catch (Exception ex){
				   	 System.out.println("오류");
				   	}
				   		}
				   	});
	     }
}