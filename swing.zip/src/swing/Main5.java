package swing;

public class Main5 {

	public static void main(String[] args) {
		Login l = new Login();
		l.login();
	}

}
